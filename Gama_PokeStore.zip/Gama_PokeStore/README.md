Olá Alô Devsss,

Hoje estamos trazendo aqui mais um desafio, para que vocês possam colocar a mão na massa e praticarem tudo que aprenderam até agora, assim possam solidificar o conhecimento, se aventurando em mais uma prática Yay



Sabendo disso, queremos que você vivencie a experiência de construir uma loja virtual, e nos mostre como você imaginaria ser uma loja de Pokémon. Isso mesmo.
Um projeto divertido.

Os Pokémon (sim, esse é o plural) deverão ser mostrados a partir da pokeapi(https://pokeapi.co/), uma api com dados de todos os Pokémon (ou quase todos).

 Após requisitar os Pokémon, os preços podem ser definidos aleatoriamente, só esteja preocupado em manter a consistência entre o carrinho lateral e o preço mostrado no catálogo.